
import Foundation
import SwiftUI

class QuizSohanViewModel: ObservableObject {
    @Published var quiz = QuizSohanModel()
    @Published var totalCounts = 0
    @Published var exp = "Expression"
    @Published var solu = "Solution"
    
    
    func RandomNumbersGeneration(){
        quiz.number1 = Int.random(in: 0...100)
        quiz.number2 = Int.random(in: 0...100)
    }
    
    func updateExp(){
        exp = "\(quiz.number1 ?? 0) + \(quiz.number2 ?? 0)"
    }
    func updateSol() {
        if let num1 = quiz.number1, let num2 = quiz.number2 {
            solu = "\(num1 + num2)"
        } else {
            solu = "N/A"
        }
    }
    
    func incrementTotalCounts(){
        totalCounts+=1
    }

}
