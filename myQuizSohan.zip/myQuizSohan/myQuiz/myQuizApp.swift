//
//  myQuizApp.swift
//  myQuiz
//
//  Created by Sohan Thakur on 2/1/24.
//

import SwiftUI

@main
struct myQuizApp: App {
    var body: some Scene {
        WindowGroup {
            QuizSohanView()
        }
    }
}
