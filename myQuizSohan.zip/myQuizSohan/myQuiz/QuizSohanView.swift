import SwiftUI

struct QuizSohanView: View {
    @ObservedObject var quizViewModel = QuizSohanViewModel()

    var body: some View {
        VStack {
            Spacer()
            Text(quizViewModel.exp)
                .font(.title)
                .foregroundColor(.red)
                .padding()
            
            
            Text(quizViewModel.solu)
                .font(.title)
                .foregroundColor(.green)
                .padding()

            
            
            HStack {
                Text("Total Counts: \(quizViewModel.totalCounts)")
                    .padding(.leading, 10)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                                       

                Button(action: {
                    self.quizViewModel.RandomNumbersGeneration()
                    quizViewModel.updateExp()
                    quizViewModel.incrementTotalCounts()
                    quizViewModel.updateSol()
                    
                }) {
                    Text(quizViewModel.totalCounts == 0 ? "Play" : "Play Again")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.green)
                        .cornerRadius(25)
                }
                .padding()
                            }
            
            Spacer()
        }
        .padding()
        .background(Color.yellow.opacity(0.2))
        .navigationBarTitle("myQuiz", displayMode: .inline)
    }
}

struct MyQuizView_Previews: PreviewProvider {
    static var previews: some View {
        QuizSohanView()
    }
}
