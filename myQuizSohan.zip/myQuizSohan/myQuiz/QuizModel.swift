//
//  QuizModel.swift
//  myQuiz
//
//  Created by Sohan thakur on 2/1/24.
//

import Foundation
struct QuizSohanModel{
    var number1: Int?
    var number2: Int?
    var sol: Int?
}
